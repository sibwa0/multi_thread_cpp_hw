#include <iostream>
#include "utils.hpp"


int some_free(const Resource& obj, int x) {
    // std::cout << "some_free call: " << x << std::endl;
    return x;
}